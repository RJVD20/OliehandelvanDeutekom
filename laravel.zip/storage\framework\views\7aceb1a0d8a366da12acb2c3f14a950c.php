<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <?php echo $__env->yieldContent('meta'); ?>
    <title><?php echo $__env->yieldContent('title', 'Webshop'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 text-gray-900">

<?php echo $__env->make('themes.default.components.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
    <?php echo $__env->yieldContent('content'); ?>
</main>

<?php echo $__env->make('themes.default.components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div
    x-data="{
        show: <?php echo e(session()->has('toast') ? 'true' : 'false'); ?>,
        message: '<?php echo e(session('toast')); ?>'
    }"
    x-init="
        if (show) {
            setTimeout(() => show = false, 3000);
        }
    "
    x-show="show"
    x-transition
    class="fixed top-6 right-6 bg-green-600 text-white px-6 py-3 rounded-lg shadow-lg z-50"
    style="display: none;"
>
    <span x-text="message"></span>
</div>



</body>
</html>
<?php /**PATH C:\Users\robin\Herd\OliehandelvanDeutekom\resources\views/themes/default/layouts/app.blade.php ENDPATH**/ ?>