<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Admin – <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="bg-gray-100 text-gray-900" x-data="{ menuOpen: false }">

<div class="flex min-h-screen">

    
    <aside
        class="fixed inset-y-0 left-0 w-64 bg-gradient-to-b from-gray-900 to-gray-800 text-white flex flex-col px-4 py-6 transform transition-transform duration-200 md:translate-x-0 z-40"
        :class="menuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'"
    >

        
        <div class="mb-8 flex items-center justify-between md:block">
            <div>
                <h1 class="text-xl font-bold">Admin</h1>
                <p class="text-xs text-gray-400">Beheeromgeving</p>
            </div>
            <button class="md:hidden text-gray-300" @click="menuOpen = false">✕</button>
        </div>

        
        <nav class="flex-1 space-y-1 text-sm overflow-y-auto">
            <a href="<?php echo e(route('admin.dashboard')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->routeIs('admin.dashboard') ? 'bg-gray-700' : 'hover:bg-gray-700'); ?>">
                📊 Dashboard
            </a>

            <a href="<?php echo e(route('admin.orders.index')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->routeIs('admin.orders.*') ? 'bg-gray-700' : 'hover:bg-gray-700'); ?>">
                📦 Bestellingen
            </a>

            <a href="<?php echo e(route('admin.routes.index')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->routeIs('admin.routes.*') ? 'bg-gray-700' : 'hover:bg-gray-700'); ?>">
                🗺️ Routes
            </a>

            <a href="<?php echo e(route('admin.products.index')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->routeIs('admin.products.*') ? 'bg-gray-700' : 'hover:bg-gray-700'); ?>">
                🛒 Producten
            </a>

            <a href="<?php echo e(route('admin.users.index')); ?>"
               class="flex items-center gap-3 px-3 py-2 rounded
               <?php echo e(request()->routeIs('admin.users.*') ? 'bg-gray-700' : 'hover:bg-gray-700'); ?>">
                👥 Gebruikers
            </a>
        </nav>

        
        <div class="border-t border-gray-700 pt-4 text-xs text-gray-400">
            <div class="flex items-center justify-between">
                <div>
                    Ingelogd als<br>
                    <span class="text-white font-medium">
                        <?php echo e(auth()->user()->name); ?>

                    </span>
                </div>

                <a href="<?php echo e(route('home')); ?>" class="ml-4 inline-block px-3 py-2 bg-green-600 text-white text-sm rounded">Naar site</a>
            </div>
        </div>

    </aside>

    
    <div
        class="fixed inset-0 bg-black/40 z-30 md:hidden"
        x-show="menuOpen"
        x-transition.opacity
        @click="menuOpen = false"
        style="display:none;"
    ></div>

    
    <main class="flex-1 md:ml-64 w-full">
        <div class="flex items-center justify-between px-4 py-4 border-b bg-white md:hidden">
            <button class="p-2 rounded bg-gray-100" @click="menuOpen = true">☰</button>
            <div class="text-sm text-gray-600">Admin</div>
            <a href="<?php echo e(route('home')); ?>" class="text-sm text-green-700">Naar site</a>
        </div>
        <div class="p-4 sm:p-6 lg:p-8">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

</div>

<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\robin\Herd\OliehandelvanDeutekom\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>