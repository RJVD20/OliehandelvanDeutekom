<img
    src="{{ asset('images/logovd.png') }}"
    alt="Oliehandel van Deutekom"
    {{ $attributes->merge(['class' => 'h-12 w-auto']) }}
>
