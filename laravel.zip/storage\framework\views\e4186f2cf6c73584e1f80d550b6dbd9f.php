<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-6">Dashboard</h1>

<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
	<div class="bg-white p-4 rounded shadow">
		<div class="text-sm text-gray-500">Totaal producten</div>
		<div class="text-2xl font-semibold"><?php echo e($totalProducts); ?></div>
		<div class="text-xs text-gray-400">Actief: <?php echo e($activeProducts); ?> — Inactief: <?php echo e($inactiveProducts); ?></div>
	</div>

	<div class="bg-white p-4 rounded shadow">
		<div class="text-sm text-gray-500">Totaal bestellingen</div>
		<div class="text-2xl font-semibold"><?php echo e($totalOrders); ?></div>
		<div class="text-xs text-gray-400">Recente bestellingen: <?php echo e($recentOrders->count()); ?></div>
	</div>

	<div class="bg-white p-4 rounded shadow">
		<div class="text-sm text-gray-500">Snelle acties</div>
		<div class="mt-3 flex flex-col gap-2">
			<a href="<?php echo e(route('admin.products.create')); ?>" class="inline-block px-3 py-2 bg-green-600 text-white rounded">Nieuw product</a>
			<a href="<?php echo e(route('admin.products.index')); ?>" class="inline-block px-3 py-2 bg-blue-600 text-white rounded">Maak producten beheer</a>
			<a href="<?php echo e(route('admin.orders.index')); ?>" class="inline-block px-3 py-2 bg-yellow-600 text-white rounded">Bekijk bestellingen</a>
		</div>

		<div class="mt-4 pt-4 border-t">
			<div class="text-sm text-gray-500 mb-2">Onderhoudsmodus</div>
			<div class="text-xs text-gray-500 mb-3">
				Status:
				<span class="font-semibold <?php echo e($maintenanceEnabled ? 'text-red-700' : 'text-green-700'); ?>">
					<?php echo e($maintenanceEnabled ? 'AAN' : 'UIT'); ?>

				</span>
			</div>

			<form method="POST" action="<?php echo e(route('admin.maintenance.toggle')); ?>">
				<?php echo csrf_field(); ?>
				<button type="submit"
					class="inline-block px-3 py-2 text-white rounded <?php echo e($maintenanceEnabled ? 'bg-gray-800' : 'bg-red-600'); ?>">
					<?php echo e($maintenanceEnabled ? 'Onderhoud UIT zetten' : 'Onderhoud AAN zetten'); ?>

				</button>
			</form>

			<p class="text-xs text-gray-400 mt-2">
				Bezoekers zien de onderhoudspagina; admins kunnen nog inloggen.
			</p>
		</div>
	</div>
</div>

<div class="bg-white p-4 rounded shadow">
	<h2 class="font-semibold mb-4">Recente bestellingen</h2>

	<?php if($recentOrders->isEmpty()): ?>
		<p class="text-sm text-gray-500">Geen recente bestellingen.</p>
	<?php else: ?>
		<div class="overflow-x-auto">
			<table class="w-full text-left text-sm">
				<thead>
					<tr class="border-b">
						<th class="p-2">#</th>
						<th class="p-2">Naam</th>
						<th class="p-2">Datum</th>
						<th class="p-2">Totaal</th>
						<th class="p-2"></th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $recentOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr class="border-b hover:bg-gray-50">
							<td class="p-2"><?php echo e($order->id); ?></td>
							<td class="p-2"><?php echo e($order->name); ?></td>
							<td class="p-2"><?php echo e($order->created_at->format('d-m-Y')); ?></td>
							<td class="p-2">€ <?php echo e(number_format($order->total, 2, ',', '.')); ?></td>
							<td class="p-2 text-right">
								<a href="<?php echo e(route('admin.orders.show', $order)); ?>" class="text-blue-600">Bekijken →</a>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robin\Herd\OliehandelvanDeutekom\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>