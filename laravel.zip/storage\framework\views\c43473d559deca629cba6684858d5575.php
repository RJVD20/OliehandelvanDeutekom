<img
    src="<?php echo e(asset('images/logovd.png')); ?>"
    alt="Oliehandel van Deutekom"
    <?php echo e($attributes->merge(['class' => 'h-12 w-auto'])); ?>

>
<?php /**PATH C:\Users\robin\Herd\OliehandelvanDeutekom\resources\views/components/application-logo.blade.php ENDPATH**/ ?>