<?php $__env->startSection('title', 'Alle producten'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="text-3xl font-bold text-green-700 mb-8">
    Alle producten
</h1>

<div class="grid grid-cols-1 lg:grid-cols-4 gap-10">

    <!-- FILTER SIDEBAR -->
    <aside class="lg:col-span-1">

        <form
            method="GET"
            action="<?php echo e(route('products.index')); ?>"
            x-data="{
                min: <?php echo e(request('min_price', 0)); ?>,
                max: <?php echo e(request('max_price', 500)); ?>

            }"
            @change="$el.submit()"
            class="space-y-8"
        >

            <!-- CATEGORIE -->
            <div>
                <h3 class="font-semibold mb-3">Categorie</h3>
                <ul class="space-y-2 text-sm">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label class="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    name="categories[]"
                                    value="<?php echo e($category->id); ?>"
                                    <?php if(in_array((string) $category->id, request('categories', []))): echo 'checked'; endif; ?>
                                    class="accent-green-600"
                                >
                                <?php echo e($category->name); ?>

                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- TYPE -->
            <div>
                <h3 class="font-semibold mb-3">Type</h3>
                <ul class="space-y-2 text-sm">
                    <?php $__currentLoopData = ['kachel','vloeistof','pellet','accessoire']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <label class="flex items-center gap-2">
                                <input
                                    type="checkbox"
                                    name="types[]"
                                    value="<?php echo e($type); ?>"
                                    <?php if(in_array($type, request('types', []))): echo 'checked'; endif; ?>
                                    class="accent-green-600"
                                >
                                <?php echo e(ucfirst($type)); ?>

                            </label>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <!-- PRIJS -->
            <div class="space-y-3">
                <h3 class="font-semibold">Prijs</h3>

                <input type="range" min="0" max="500" step="5" x-model="min">
                <input type="range" min="0" max="500" step="5" x-model="max">

                <div class="text-sm text-gray-600">
                    € <span x-text="min"></span> - € <span x-text="max"></span>
                </div>

                <input type="hidden" name="min_price" :value="min">
                <input type="hidden" name="max_price" :value="max">
            </div>

        </form>

    </aside>

    <!-- PRODUCT GRID -->
    <section class="lg:col-span-3">

        <!-- TOP BAR -->
        <div class="flex justify-between items-center mb-6">

            <p class="text-sm text-gray-500">
                <?php echo e($products->total()); ?> producten gevonden
            </p>

            <!-- SORTEREN -->
            <form method="GET" action="<?php echo e(route('products.index')); ?>">
                
                <?php $__currentLoopData = request()->except('sort', 'page'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_array($value)): ?>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($key); ?>[]" value="<?php echo e($v); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <select
                    name="sort"
                    onchange="this.form.submit()"
                    class="border rounded p-2 text-sm"
                >
                    <option value="">Sorteren op</option>
                    <option value="price_asc" <?php if(request('sort') === 'price_asc'): echo 'selected'; endif; ?>>
                        Prijs: laag → hoog
                    </option>
                    <option value="price_desc" <?php if(request('sort') === 'price_desc'): echo 'selected'; endif; ?>>
                        Prijs: hoog → laag
                    </option>
                    <option value="newest" <?php if(request('sort') === 'newest'): echo 'selected'; endif; ?>>
                        Nieuwste eerst
                    </option>
                </select>
            </form>

        </div>

        <!-- PRODUCTEN -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bg-white border rounded-lg shadow-sm hover:shadow-md transition group">

                    <a
                        href="<?php echo e(route('product.show', $product->slug)); ?>"
                        class="block h-44 bg-green-50 flex items-center justify-center rounded-t-lg group-hover:bg-green-100 transition"
                    >
                        <span class="text-green-700 font-semibold text-center px-3">
                            <?php echo e($product->name); ?>

                        </span>
                    </a>

                    <div class="p-4">
                        <h3 class="font-semibold mb-1">
                            <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="hover:text-green-700">
                                <?php echo e($product->name); ?>

                            </a>
                        </h3>

                        <p class="text-sm text-gray-500 mb-3 line-clamp-2">
                            <?php echo e($product->description); ?>

                        </p>

                        <div class="flex items-center justify-between">
                            <span class="font-bold text-green-700">
                                € <?php echo e(number_format($product->price, 2, ',', '.')); ?>

                            </span>

                            <form method="POST" action="<?php echo e(route('cart.add', $product->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700">
                                    In winkelmand
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="col-span-3 text-gray-500">
                    Geen producten gevonden.
                </p>
            <?php endif; ?>
        </div>

        <!-- PAGINATION -->
        <div class="mt-10">
            <?php echo e($products->withQueryString()->links()); ?>

        </div>

    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('themes.default.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\robin\Herd\OliehandelvanDeutekom\resources\views/themes/default/pages/products/index.blade.php ENDPATH**/ ?>